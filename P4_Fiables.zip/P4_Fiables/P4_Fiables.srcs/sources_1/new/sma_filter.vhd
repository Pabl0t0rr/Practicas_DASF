library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity sma_filter is
    generic (
        N     : integer := 4;
        WIDTH : integer := 8
    );
    Port (
        clk   : in  STD_LOGIC;
        rst   : in  STD_LOGIC;
        din   : in  STD_LOGIC_VECTOR (WIDTH-1 downto 0);
        load  : in  STD_LOGIC;
        dout  : out STD_LOGIC_VECTOR (WIDTH-1 downto 0)
    );
end sma_filter;

architecture Behavioral of sma_filter is
    type data_array is array (0 to 3) of unsigned(7 downto 0);
    signal samples : data_array := (others => (others => '0'));
    signal sum     : unsigned(9 downto 0) := (others => '0'); -- 10 bits to prevent overflow
    signal avg     : unsigned(7 downto 0);
    signal index : integer range 0 to N-1 := 0;
    --signal count : integer range 0 to N := 0;
begin
    process(clk, rst)
    begin
        if rst = '1' then
            samples <= (others => (others => '0'));
            sum     <= (others => '0');
            avg     <= (others => '0');
            index   <= 0;
            --count   <= 0;
        elsif rising_edge(clk) then
            if load = '1' then
                sum <= sum - ("00" & samples(index)) + ("00" & unsigned(din));
                samples(index) <= unsigned(din);
                
                if index = N-1 then
                    index <= 0;
                else
                    index <= index + 1;
                end if;
                -- sum(9 downto 2); -- Hacemos 2 desplazamientos por dividir en 4
                avg <= shift_right (sum, 2)(7 downto 0);
        
            end if;
            dout <= std_logic_vector(avg);
        end if;
        
    end process;

   
end Behavioral;